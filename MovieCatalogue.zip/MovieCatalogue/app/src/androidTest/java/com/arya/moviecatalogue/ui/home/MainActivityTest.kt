package com.arya.moviecatalogue.ui.home

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.UiController
import androidx.test.espresso.ViewAction
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import com.arya.moviecatalogue.R
import com.arya.moviecatalogue.model.MovieEntity
import com.arya.moviecatalogue.model.TvShowEntity
import com.arya.moviecatalogue.utils.DataMovies
import com.arya.moviecatalogue.utils.DataTvShows
import com.arya.moviecatalogue.utils.formatDate
import org.hamcrest.Matcher
import org.junit.Before
import org.junit.Test

class MainActivityTest {

    private val dataMovie = DataMovies.generateDummyMovies()
    private val dataTvShow = DataTvShows.generateDummyTvShows()
    private val emptyDataMovie =  emptyList<MovieEntity>()
    private val emptyDataTvShow = emptyList<TvShowEntity>()

    @Before
    fun setUp() {
        ActivityScenario.launch(MainActivity::class.java)
    }

    @Test
    fun loadDataMovie() {
        onView(withId(R.id.rv_movie)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_movie)).perform(
            RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(
                dataMovie.size
            )
        )
    }

    @Test
    fun loadDetailMovie() {
        onView(withId(R.id.rv_movie)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                0,
                click()
            )
        )
        onView(withId(R.id.collapsing_toolbar)).apply {
            check(matches(isDisplayed()))
        }
        onView(withId(R.id.tv_title)).apply {
            check(matches(isDisplayed()))
            check(matches(withText(dataMovie[0].title)))
        }
        onView(withId(R.id.tv_overview)).apply {
            check(matches(isDisplayed()))
            check(matches(withText(dataMovie[0].overview)))
        }
        onView(withId(R.id.tv_release)).apply {
            check(matches(isDisplayed()))
            check(matches(withText(formatDate(dataMovie[0].releaseDate.toString(), "MMM dd, yyyy"))))
        }
        onView(withId(R.id.tv_rating)).apply {
            check(matches(isDisplayed()))
            check(matches(withText(dataMovie[0].rating.toString())))
        }
        onView(withId(R.id.iv_poster)).apply {
            check(matches(isDisplayed()))
        }
        onView(withId(R.id.iv_backdrop)).apply {
            check(matches(isDisplayed()))
        }
    }

    @Test
    fun loadDataTvShow() {
        onView(withId(R.id.navigation_tvshow)).perform(click())
        onView(withId(R.id.rv_tvshow)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_tvshow)).perform(
            RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(
                dataTvShow.size
            )
        )
    }

    @Test
    fun loadDetailTvShow() {
        onView(withId(R.id.navigation_tvshow)).perform(click())
        onView(withId(R.id.rv_tvshow)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                0,
                click()
            )
        )
        onView(withId(R.id.collapsing_toolbar)).apply {
            check(matches(isDisplayed()))
        }
        onView(withId(R.id.tv_title)).apply {
            check(matches(isDisplayed()))
            check(matches(withText(dataTvShow[0].name)))
        }
        onView(withId(R.id.tv_overview)).apply {
            check(matches(isDisplayed()))
            check(matches(withText(dataTvShow[0].overview)))
        }
        onView(withId(R.id.tv_release)).apply {
            check(matches(isDisplayed()))
            check(matches(withText(formatDate(dataTvShow[0].firstAirDate.toString(), "MMM dd, yyyy"))))
        }
        onView(withId(R.id.tv_rating)).apply {
            check(matches(isDisplayed()))
            check(matches(withText(dataTvShow[0].rating.toString())))
        }
        onView(withId(R.id.iv_poster)).apply {
            check(matches(isDisplayed()))
        }
        onView(withId(R.id.iv_backdrop)).apply {
            check(matches(isDisplayed()))
        }
    }

    @Test
    fun loadEmptyData() {
        if (emptyDataMovie.isNullOrEmpty() && emptyDataTvShow.isNullOrEmpty()) {
            onView(withId(R.id.rv_movie)).perform(setVisibility(false))
            onView(withId(R.id.iv_no_data)).perform(setVisibility(true))
            onView(withId(R.id.tv_no_data)).perform(setVisibility(true))
            onView(withId(R.id.navigation_tvshow)).perform(click())
            onView(withId(R.id.rv_tvshow)).perform(setVisibility(false))
            onView(withId(R.id.iv_no_data)).perform(setVisibility(true))
            onView(withId(R.id.tv_no_data)).perform(setVisibility(true))

        }
    }

    private fun setVisibility(state: Boolean): ViewAction {
        return object : ViewAction {
            override fun getConstraints(): Matcher<View> {
                return isAssignableFrom(View::class.java)
            }

            override fun getDescription(): String {
                return "Show / Hide View"
            }

            override fun perform(uiController: UiController?, view: View) {
                view.visibility = if (state) View.VISIBLE else View.GONE
            }

        }
    }
}