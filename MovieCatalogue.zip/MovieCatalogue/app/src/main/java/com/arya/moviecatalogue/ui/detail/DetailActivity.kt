package com.arya.moviecatalogue.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.arya.moviecatalogue.databinding.ActivityDetailBinding
import com.arya.moviecatalogue.model.MovieEntity
import com.arya.moviecatalogue.model.TvShowEntity
import com.arya.moviecatalogue.utils.Const.URL_BACKDROP
import com.arya.moviecatalogue.utils.Const.URL_POSTER
import com.arya.moviecatalogue.utils.formatDate
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.request.RequestOptions

class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TYPE = "type"
        const val EXTRA_ID = "id"
    }

    private lateinit var binding: ActivityDetailBinding
    private lateinit var viewModel: DetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.hide()

        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[DetailViewModel::class.java]

        binding.toolbar.setNavigationOnClickListener { onBackPressed() }

        val type = intent.getStringExtra(EXTRA_TYPE)
        val id = intent.getStringExtra(EXTRA_ID)

        if (id != null) {
            viewModel.setSelectedId(id)
            if (type == "Movie") {
                populateMovie(viewModel.getMovieDetail())
            } else {
                populateTvShow(viewModel.getTvShowDetail())
            }
        }
    }

    private fun populateMovie(movieEntity: MovieEntity) {
        binding.apply {
            Glide.with(this@DetailActivity)
                .load(URL_BACKDROP + movieEntity.backdropPath)
                .apply(RequestOptions())
                .into(ivBackdrop)

            Glide.with(this@DetailActivity)
                .load(URL_POSTER + movieEntity.posterPath)
                .transform(CenterCrop())
                .into(ivPoster)

            tvTitle.text = movieEntity.title
            tvRelease.text = formatDate(movieEntity.releaseDate.toString(), "MMM dd, yyyy")
            ratingBar.rating = movieEntity.rating?.div(2F) ?: 0F
            tvRating.text = movieEntity.rating.toString()
            tvOverview.text = movieEntity.overview
        }
    }

    private fun populateTvShow(tvShowEntity: TvShowEntity) {
        binding.apply {
            Glide.with(this@DetailActivity)
                .load(URL_BACKDROP + tvShowEntity.backdropPath)
                .apply(RequestOptions())
                .into(ivBackdrop)

            Glide.with(this@DetailActivity)
                .load(URL_POSTER + tvShowEntity.posterPath)
                .transform(CenterCrop())
                .into(ivPoster)

            tvTitle.text = tvShowEntity.name
            tvRelease.text = formatDate(tvShowEntity.firstAirDate.toString(), "MMM dd, yyyy")
            ratingBar.rating = tvShowEntity.rating?.div(2F) ?: 0F
            tvRating.text = tvShowEntity.rating.toString()
            tvOverview.text = tvShowEntity.overview
        }
    }

}