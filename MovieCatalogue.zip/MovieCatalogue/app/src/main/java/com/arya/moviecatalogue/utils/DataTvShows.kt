package com.arya.moviecatalogue.utils

import com.arya.moviecatalogue.model.TvShowEntity

object DataTvShows {
    fun generateDummyTvShows(): List<TvShowEntity> {
        val tvShows = ArrayList<TvShowEntity>()

        tvShows.add(
            TvShowEntity(
                "0",
                "Hawkeye",
                "Former Avenger Clint Barton has a seemingly simple mission: get back to his family for Christmas. Possible? Maybe with the help of Kate Bishop, a 22-year-old archer with dreams of becoming a superhero. The two are forced to work together when a presence from Barton’s past threatens to derail far more than the festive spirit.",
                "2021-11-24",
                8.5F,
                "/pqzjCxPVc9TkVgGRWeAoMmyqkZV.jpg",
                "/1R68vl3d5s86JsS2NPjl8UoMqIS.jpg",
            )
        )

        tvShows.add(
            TvShowEntity(
                "1",
                "Chucky",
                "After a vintage Chucky doll turns up at a suburban yard sale, an idyllic American town is thrown into chaos as a series of horrifying murders begin to expose the town’s hypocrisies and secrets. Meanwhile, the arrival of enemies — and allies — from Chucky’s past threatens to expose the truth behind the killings, as well as the demon doll’s untold origins.",
                "2021-10-12",
                7.9F,
                "/iF8ai2QLNiHV4anwY1TuSGZXqfN.jpg",
                "/xAKMj134XHQVNHLC6rWsccLMenG.jpg",
            )
        )

        tvShows.add(
            TvShowEntity(
                "2",
                "The Witcher",
                "Geralt of Rivia, a mutated monster-hunter for hire, journeys toward his destiny in a turbulent world where people often prove more wicked than beasts.",
                "2019-12-20",
                8.2F,
                "/7vjaCdMw15FEbXyLQTVa04URsPm.jpg",
                "/iY6upFm468X37gqWPE7IEz3TRJx.jpg",
            )
        )

        tvShows.add(
            TvShowEntity(
                "3",
                "The Wheel of Time",
                "Follow Moiraine, a member of the shadowy and influential all-female organization called the “Aes Sedai” as she embarks on a dangerous, world-spanning journey with five young men and women. Moiraine believes one of them might be the reincarnation of an incredibly powerful individual, whom prophecies say will either save humanity or destroy it.",
                "2021-11-18",
                8.1F,
                "/mpgDeLhl8HbhI03XLB7iKO6M6JE.jpg",
                "/1P3QtW1IkivqDrKbbwuR0zCYIf8.jpg",
            )
        )

        tvShows.add(
            TvShowEntity(
                "4",
                "Squid Game",
                "Hundreds of cash-strapped players accept a strange invitation to compete in children's games—with high stakes. But, a tempting prize awaits the victor.",
                "2021-09-17",
                7.8F,
                "/dDlEmu3EZ0Pgg93K2SVNLCjCSvE.jpg",
                "/qw3J9cNeLioOLoR68WX7z79aCdK.jpg",
            )
        )

        tvShows.add(
            TvShowEntity(
                "5",
                "Money Heist",
                "To carry out the biggest heist in history, a mysterious man called The Professor recruits a band of eight robbers who have a single characteristic: none of them has anything to lose. Five months of seclusion - memorizing every step, every detail, every probability - culminate in eleven days locked up in the National Coinage and Stamp Factory of Spain, surrounded by police forces and with dozens of hostages in their power, to find out whether their suicide wager will lead to everything or nothing.",
                "2017-05-02",
                8.3F,
                "/reEMJA1uzscCbkpeRJeTT2bjqUp.jpg",
                "/gFZriCkpJYsApPZEF3jhxL4yLzG.jpg",
            )
        )

        tvShows.add(
            TvShowEntity(
                "6",
                "The Flash",
                "After a particle accelerator causes a freak storm, CSI Investigator Barry Allen is struck by lightning and falls into a coma. Months later he awakens with the power of super speed, granting him the ability to move through Central City like an unseen guardian angel. Though initially excited by his newfound powers, Barry is shocked to discover he is not the only \"meta-human\" who was created in the wake of the accelerator explosion -- and not everyone is using their new powers for good. Barry partners with S.T.A.R. Labs and dedicates his life to protect the innocent. For now, only a few close friends and associates know that Barry is literally the fastest man alive, but it won't be long before the world learns what Barry Allen has become...The Flash.",
                "2014-10-07",
                7.8F,
                "/lJA2RCMfsWoskqlQhXPSLFQGXEJ.jpg",
                "/41yaWnIT8AjIHiULHtTbKNzZTjc.jpg",
            )
        )

        tvShows.add(
            TvShowEntity(
                "7",
                "Yellowstone",
                "Follow the violent world of the Dutton family, who controls the largest contiguous ranch in the United States. Led by their patriarch John Dutton, the family defends their property against constant attack by land developers, an Indian reservation, and America’s first National Park.",
                "2018-06-20",
                8F,
                "/iqWCUwLcjkVgtpsDLs8xx8kscg6.jpg",
                "/5YTM1bh3Jyfy9IP2eS64W3JDeGs.jpg",
            )
        )

        tvShows.add(
            TvShowEntity(
                "8",
                "People Puzzler",
                "Three lucky contestants put their pop culture knowledge to the test to complete iconic, People Puzzler crosswords. The player with the most points at the end of three rounds wins the game and goes on to play the \"Fast Puzzle Round\" for an enormous cash prize.",
                "2021-01-18",
                6.8F,
                "/gELQSCY5KKIGQAmOHbcgcRGNlp5.jpg",
                "/vjcuLy14kxgxCaBToAudZWrGQQh.jpg",
            )
        )

        tvShows.add(
            TvShowEntity(
                "9",
                "Harry Potter: Hogwarts Tournament of Houses",
                "Wizarding World fans put their Harry Potter knowledge to the test for the ultimate honor to be named House Cup champion.",
                "2021-11-28",
                8.1F,
                "/tEHHfzqHnfNJUp4L30wQeYl2xRo.jpg",
                "/6W8zEF5jE9ErdhzatZBVI7fkpsP.jpg",
            )
        )

        return tvShows
    }
}