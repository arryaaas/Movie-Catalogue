package com.arya.moviecatalogue.ui.movie

import androidx.lifecycle.ViewModel
import com.arya.moviecatalogue.model.MovieEntity
import com.arya.moviecatalogue.utils.DataMovies

class MovieViewModel : ViewModel() {

    fun getMovies(): List<MovieEntity> = DataMovies.generateDummyMovies()
}