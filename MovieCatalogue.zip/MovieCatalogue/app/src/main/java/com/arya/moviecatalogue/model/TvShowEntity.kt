package com.arya.moviecatalogue.model

import android.os.Parcel
import android.os.Parcelable

data class TvShowEntity(
    var id: String? = null,
    var name: String? = null,
    var overview: String? = null,
    var firstAirDate: String? = null,
    var rating: Float? = 0F,
    var posterPath: String? = null,
    var backdropPath: String? = null,
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readValue(Float::class.java.classLoader) as? Float,
        parcel.readString(),
        parcel.readString()
    )

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(p0: Parcel, p1: Int) {
        p0.writeString(id)
        p0.writeString(name)
        p0.writeString(overview)
        p0.writeString(firstAirDate)
        rating?.let { p0.writeFloat(it) }
        p0.writeString(posterPath)
        p0.writeString(backdropPath)
    }

    companion object CREATOR : Parcelable.Creator<TvShowEntity> {
        override fun createFromParcel(parcel: Parcel): TvShowEntity {
            return TvShowEntity(parcel)
        }

        override fun newArray(size: Int): Array<TvShowEntity?> {
            return arrayOfNulls(size)
        }
    }
}