package com.arya.moviecatalogue.ui.movie

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.arya.moviecatalogue.databinding.ItemListBinding
import com.arya.moviecatalogue.model.MovieEntity
import com.arya.moviecatalogue.ui.detail.DetailActivity
import com.arya.moviecatalogue.utils.Const.URL_POSTER
import com.arya.moviecatalogue.utils.formatDate
import com.bumptech.glide.Glide

class MovieAdapter: RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

    private var listMovies = ArrayList<MovieEntity>()

    fun setMovie(movies: List<MovieEntity>) {
        listMovies.apply {
            clear()
            addAll(movies)
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MovieAdapter.MovieViewHolder {
        return MovieViewHolder(
            ItemListBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: MovieAdapter.MovieViewHolder, position: Int) {
        val movie = listMovies[position]
        holder.bind(movie)
    }

    override fun getItemCount(): Int = listMovies.size

    inner class MovieViewHolder(private val binding: ItemListBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(movie: MovieEntity) {
            binding.apply {
                Glide.with(itemView.context)
                    .load(URL_POSTER + movie.posterPath)
                    .into(ivPoster)

                tvTitle.text = movie.title
                tvRelease.text = formatDate(movie.releaseDate.toString(), "MMM dd, yyyy")
                ratingBar.rating = movie.rating?.div(2F) ?: 0F
                tvRating.text = movie.rating.toString()

                itemView.setOnClickListener {
                    Log.d("Movie Adapter", "Item Clicked")
                    val intent = Intent(itemView.context, DetailActivity::class.java).apply {
                        putExtra(DetailActivity.EXTRA_TYPE, "Movie")
                        putExtra(DetailActivity.EXTRA_ID, movie.id)
                    }
                    itemView.context.startActivity(intent)
                }
            }
        }
    }
}