package com.arya.moviecatalogue.ui.tvshow

import androidx.lifecycle.ViewModel
import com.arya.moviecatalogue.model.TvShowEntity
import com.arya.moviecatalogue.utils.DataTvShows

class TvShowViewModel : ViewModel() {

    fun getTvShows(): List<TvShowEntity> = DataTvShows.generateDummyTvShows()
}