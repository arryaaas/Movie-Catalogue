package com.arya.moviecatalogue.utils

import com.arya.moviecatalogue.model.MovieEntity

object DataMovies {
    fun generateDummyMovies(): List<MovieEntity> {
        val movies = ArrayList<MovieEntity>()

        movies.add(
            MovieEntity(
                "0",
                "Spider-Man: No Way Home",
                "Peter Parker is unmasked and no longer able to separate his normal life from the high-stakes of being a super-hero. When he asks for help from Doctor Strange the stakes become even more dangerous, forcing him to discover what it truly means to be Spider-Man.",
                "2021-12-15",
                8.5F,
                "/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg",
                "/1Rr5SrvHxMXHu5RjKpaMba8VTzi.jpg",
            )
        )

        movies.add(
            MovieEntity(
                "1",
                "Venom: Let There Be Carnage",
                "After finding a host body in investigative reporter Eddie Brock, the alien symbiote must face a new enemy, Carnage, the alter ego of serial killer Cletus Kasady.",
                "2021-09-30",
                7.2F,
                "/rjkmN1dniUHVYAtwuV3Tji7FsDO.jpg",
                "/eENEf62tMXbhyVvdcXlnQz2wcuT.jpg",
            )
        )

        movies.add(
            MovieEntity(
                "2",
                "Red Notice",
                "An Interpol-issued Red Notice is a global alert to hunt and capture the world's most wanted. But when a daring heist brings together the FBI's top profiler and two rival criminals, there's no telling what will happen.",
                "2021-11-04",
                6.8F,
                "/lAXONuqg41NwUMuzMiFvicDET9Y.jpg",
                "/dK12GIdhGP6NPGFssK2Fh265jyr.jpg",
            )
        )

        movies.add(
            MovieEntity(
                "3",
                "Sooryavanshi",
                "A fearless, faithful albeit slightly forgetful Mumbai cop, Veer Sooryavanshi, the chief of the Anti-Terrorism Squad in India pulls out all the stops and stunts to thwart a major conspiracy to attack his city.",
                "2021-11-05",
                6.2F,
                "/1vuix8r1CJ2M6IldR27Z95hWm7e.jpg",
                "/gg2w8QYf6o5elN95RHtikQaVIsc.jpg",
            )
        )

        movies.add(
            MovieEntity(
                "4",
                "Shang-Chi and the Legend of the Ten Rings",
                "Shang-Chi must confront the past he thought he left behind when he is drawn into the web of the mysterious Ten Rings organization.",
                "2021-09-01",
                7.8F,
                "/1BIoJGKbXjdFDAqUEiA2VHqkK1Z.jpg",
                "/cinER0ESG0eJ49kXlExM0MEWGxW.jpg",
            )
        )

        movies.add(
            MovieEntity(
                "5",
                "Spider-Man: Homecoming",
                "Following the events of Captain America: Civil War, Peter Parker, with the help of his mentor Tony Stark, tries to balance his life as an ordinary high school student in Queens, New York City, with fighting crime as his superhero alter ego Spider-Man as a new threat, the Vulture, emerges.",
                "2017-07-05",
                7.4F,
                "/c24sv2weTHPsmDa7jEMN0m2P3RT.jpg",
                "/tTlAA0REGPXSZPBfWyTW9ipIv1I.jpg",
            )
        )

        movies.add(
            MovieEntity(
                "6",
                "The Amazing Spider-Man",
                "Peter Parker is an outcast high schooler abandoned by his parents as a boy, leaving him to be raised by his Uncle Ben and Aunt May. Like most teenagers, Peter is trying to figure out who he is and how he got to be the person he is today. As Peter discovers a mysterious briefcase that belonged to his father, he begins a quest to understand his parents' disappearance – leading him directly to Oscorp and the lab of Dr. Curt Connors, his father's former partner. As Spider-Man is set on a collision course with Connors' alter ego, The Lizard, Peter will make life-altering choices to use his powers and shape his destiny to become a hero.",
                "2012-06-23",
                6.6F,
                "/fSbqPbqXa7ePo8bcnZYN9AHv6zA.jpg",
                "/sLWUtbrpiLp23a0XDSiUiltdFPJ.jpg",
            )
        )

        movies.add(
            MovieEntity(
                "7",
                "Encanto",
                "The tale of an extraordinary family, the Madrigals, who live hidden in the mountains of Colombia, in a magical house, in a vibrant town, in a wondrous, charmed place called an Encanto. The magic of the Encanto has blessed every child in the family with a unique gift from super strength to the power to heal—every child except one, Mirabel. But when she discovers that the magic surrounding the Encanto is in danger, Mirabel decides that she, the only ordinary Madrigal, might just be her exceptional family's last hope.",
                "2021-11-24",
                7.3F,
                "/4j0PNHkMr5ax3IA8tjtxcmPU3QT.jpg",
                "/5RuR7GhOI5fElADXZb0X2sr9w5n.jpg",
            )
        )

        movies.add(
            MovieEntity(
                "8",
                "Clifford the Big Red Dog",
                "As Emily struggles to fit in at home and at school, she discovers a small red puppy who is destined to become her best friend. When Clifford magically undergoes one heck of a growth spurt, becomes a gigantic dog and attracts the attention of a genetics company, Emily and her Uncle Casey have to fight the forces of greed as they go on the run across New York City. Along the way, Clifford affects the lives of everyone around him and teaches Emily and her uncle the true meaning of acceptance and unconditional love.",
                "2021-11-10",
                7.5F,
                "/30ULVKdjBcQTsj2aOSThXXZNSxF.jpg",
                "/1Wlwnhn5sXUIwlxpJgWszT622PS.jpg",
            )
        )

        movies.add(
            MovieEntity(
                "9",
                "Spider-Man: Far From Home",
                "Peter Parker and his friends go on a summer trip to Europe. However, they will hardly be able to rest - Peter will have to agree to help Nick Fury uncover the mystery of creatures that cause natural disasters and destruction throughout the continent.",
                "2019-06-28",
                7.5F,
                "/4q2NNj4S5dG2RLF9CpXsej7yXl.jpg",
                "/ng6SSB3JhbcpKTwbPDsRwUYK8Cq.jpg",
            )
        )

        return movies
    }
}