package com.arya.moviecatalogue.ui.detail

import androidx.lifecycle.ViewModel
import com.arya.moviecatalogue.model.MovieEntity
import com.arya.moviecatalogue.model.TvShowEntity
import com.arya.moviecatalogue.utils.DataMovies
import com.arya.moviecatalogue.utils.DataTvShows

class DetailViewModel : ViewModel() {

    private lateinit var id: String

    fun setSelectedId(id: String) {
        this.id = id
    }

    fun getMovieDetail(): MovieEntity {
        lateinit var selectedMovie: MovieEntity
        val movies = DataMovies.generateDummyMovies()
        for (itemMovie in movies) {
            if (itemMovie.id == id) {
                selectedMovie = itemMovie
            }
        }

        return selectedMovie
    }

    fun getTvShowDetail(): TvShowEntity {
        lateinit var selectedTvShow: TvShowEntity
        val tvShow = DataTvShows.generateDummyTvShows()
        for (itemTvShow in tvShow) {
            if (itemTvShow.id == id) {
                selectedTvShow = itemTvShow
            }
        }

        return selectedTvShow
    }
}