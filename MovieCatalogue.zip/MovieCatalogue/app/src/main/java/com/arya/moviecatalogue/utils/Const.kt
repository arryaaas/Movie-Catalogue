package com.arya.moviecatalogue.utils

object Const {

    const val URL_POSTER = "https://image.tmdb.org/t/p/w342"
    const val URL_BACKDROP = "https://image.tmdb.org/t/p/w1280"

}