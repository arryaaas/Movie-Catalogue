package com.arya.moviecatalogue.ui.detail

import com.arya.moviecatalogue.utils.DataMovies
import com.arya.moviecatalogue.utils.DataTvShows
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class DetailViewModelTest {

    private lateinit var viewModel: DetailViewModel

    private val dataMovie = DataMovies.generateDummyMovies()[0]
    private val dataMovieId = dataMovie.id.toString()

    private val dataTvShow = DataTvShows.generateDummyTvShows()[0]
    private val dataTvShowId = dataTvShow.id.toString()

    @Before
    fun setUpMovie() {
        viewModel = DetailViewModel()
        viewModel.setSelectedId(dataMovieId)
    }

    @Test
    fun getMovieDetail() {
        val movie = viewModel.getMovieDetail()
        assertNotNull(movie)
        assertEquals(dataMovie.id, movie.id)
        assertEquals(dataMovie.title, movie.title)
        assertEquals(dataMovie.overview, movie.overview)
        assertEquals(dataMovie.releaseDate, movie.releaseDate)
        assertEquals(dataMovie.rating, movie.rating)
        assertEquals(dataMovie.posterPath, movie.posterPath)
        assertEquals(dataMovie.backdropPath, movie.backdropPath)
    }

    @Before
    fun setUpTvShow() {
        viewModel = DetailViewModel()
        viewModel.setSelectedId(dataTvShowId)
    }

    @Test
    fun getTvShowDetail() {
        val tvShow = viewModel.getTvShowDetail()
        assertNotNull(tvShow)
        assertEquals(dataTvShow.id, tvShow.id)
        assertEquals(dataTvShow.name, tvShow.name)
        assertEquals(dataTvShow.overview, tvShow.overview)
        assertEquals(dataTvShow.firstAirDate, tvShow.firstAirDate)
        assertEquals(dataTvShow.rating, tvShow.rating)
        assertEquals(dataTvShow.posterPath, tvShow.posterPath)
        assertEquals(dataTvShow.backdropPath, tvShow.backdropPath)
    }
}