package com.arya.moviecatalogue.ui.movie

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class MovieViewModelTest {

    private lateinit var viewModel: MovieViewModel

    @Before
    fun setUp() {
        viewModel = MovieViewModel()
    }

    @Test
    fun getMovies() {
        val dataMovie = viewModel.getMovies()
        assertNotNull(dataMovie)
        assertEquals(10, dataMovie.size)
    }

}