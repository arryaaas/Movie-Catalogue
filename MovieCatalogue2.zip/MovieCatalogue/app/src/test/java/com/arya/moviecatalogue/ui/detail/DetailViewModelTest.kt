package com.arya.moviecatalogue.ui.detail

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.arya.moviecatalogue.data.source.MovieRepository
import com.arya.moviecatalogue.data.source.local.entity.DetailEntity
import com.arya.moviecatalogue.utils.DataDummy
import com.nhaarman.mockitokotlin2.verify
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class DetailViewModelTest {

    private lateinit var viewModel: DetailViewModel

    private val dummyMovie = DataDummy.generateDummyMovies()[0]
    private val movieId = dummyMovie.id
    private val dummyMovieDetail = DataDummy.generateDummyMovieDetail()

    private val dummyTvShow = DataDummy.generateDummyTvShows()[0]
    private val tvShowId = dummyTvShow.id
    private val dummyTvShowDetail = DataDummy.generateDummyTvShowDetail()

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var movieRepository: MovieRepository

    @Mock
    private lateinit var observer: Observer<DetailEntity>

    @Before
    fun setUp() {
        viewModel = DetailViewModel(movieRepository)
    }

    @Test
    fun getMovieDetail() {
        val movie = MutableLiveData<DetailEntity>()
        movie.value = dummyMovieDetail

        `when`(movieId?.let { movieRepository.getMovieDetail(it) }).thenReturn(movie)
        movieId?.let { viewModel.setSelectedId(it) }
        val detailEntity = viewModel.getMovieDetail().value as DetailEntity
        movieId?.let { verify(movieRepository).getMovieDetail(it) }
        assertNotNull(detailEntity)
        assertEquals(dummyMovieDetail.id, detailEntity.id)
        assertEquals(dummyMovieDetail.title, detailEntity.title)
        assertEquals(dummyMovieDetail.overview, detailEntity.overview)
        assertEquals(dummyMovieDetail.releaseDate, detailEntity.releaseDate)
        assertEquals(dummyMovieDetail.rating, detailEntity.rating)
        assertEquals(dummyMovieDetail.posterPath, detailEntity.posterPath)
        assertEquals(dummyMovieDetail.backdropPath, detailEntity.backdropPath)
        assertEquals(dummyMovieDetail.genres, detailEntity.genres)
        assertEquals(dummyMovieDetail.runtime, detailEntity.runtime)
        assertEquals(dummyMovieDetail.language, detailEntity.language)
        assertEquals(dummyMovieDetail.homepage, detailEntity.homepage)

        viewModel.getMovieDetail().observeForever(observer)
        verify(observer).onChanged(dummyMovieDetail)
    }

    @Test
    fun getTvShowDetail() {
        val tvShow = MutableLiveData<DetailEntity>()
        tvShow.value = dummyTvShowDetail

        `when`(tvShowId?.let { movieRepository.getTvShowDetail(it) }).thenReturn(tvShow)
        tvShowId?.let { viewModel.setSelectedId(it) }
        val detailEntity = viewModel.getTvShowDetail().value as DetailEntity
        tvShowId?.let { verify(movieRepository).getTvShowDetail(it) }
        assertNotNull(detailEntity)
        assertEquals(dummyTvShowDetail.id, detailEntity.id)
        assertEquals(dummyTvShowDetail.title, detailEntity.title)
        assertEquals(dummyTvShowDetail.overview, detailEntity.overview)
        assertEquals(dummyTvShowDetail.releaseDate, detailEntity.releaseDate)
        assertEquals(dummyTvShowDetail.rating, detailEntity.rating)
        assertEquals(dummyTvShowDetail.posterPath, detailEntity.posterPath)
        assertEquals(dummyTvShowDetail.backdropPath, detailEntity.backdropPath)
        assertEquals(dummyTvShowDetail.genres, detailEntity.genres)
        assertEquals(dummyTvShowDetail.runtime, detailEntity.runtime)
        assertEquals(dummyTvShowDetail.language, detailEntity.language)
        assertEquals(dummyTvShowDetail.homepage, detailEntity.homepage)

        viewModel.getTvShowDetail().observeForever(observer)
        verify(observer).onChanged(dummyTvShowDetail)
    }

}