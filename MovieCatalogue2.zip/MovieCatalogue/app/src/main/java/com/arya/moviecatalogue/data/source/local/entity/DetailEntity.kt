package com.arya.moviecatalogue.data.source.local.entity

import android.os.Parcel
import android.os.Parcelable

data class DetailEntity(
    var id: Int? = 0,
    var title: String? = null,
    var overview: String? = null,
    var releaseDate: String? = null,
    var rating: Float? = 0F,
    var posterPath: String? = null,
    var backdropPath: String? = null,
    var genres: List<String>? = null,
    var runtime: Int? = 0,
    var language: String? = null,
    var homepage: String? = null,
): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readValue(Int::class.java.classLoader) as? Int,
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readValue(Float::class.java.classLoader) as? Float,
        parcel.readString(),
        parcel.readString(),
        parcel.createStringArrayList(),
        parcel.readInt(),
        parcel.readString(),
        parcel.readString()
    )

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(p0: Parcel, p1: Int) {
        id?.let { p0.writeInt(it) }
        p0.writeString(title)
        p0.writeString(overview)
        p0.writeString(releaseDate)
        rating?.let { p0.writeFloat(it) }
        p0.writeString(posterPath)
        p0.writeString(backdropPath)
        p0.writeList(genres)
        runtime?.let { p0.writeInt(it) }
        p0.writeString(language)
        p0.writeString(homepage)
    }

    companion object CREATOR : Parcelable.Creator<DetailEntity> {
        override fun createFromParcel(parcel: Parcel): DetailEntity {
            return DetailEntity(parcel)
        }

        override fun newArray(size: Int): Array<DetailEntity?> {
            return arrayOfNulls(size)
        }
    }
}