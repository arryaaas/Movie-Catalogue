package com.arya.moviecatalogue.utils

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

fun formatDate(date: String, format: String): String {
    var formattedDate = ""
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    sdf.timeZone = TimeZone.getTimeZone("UTC")

    try {
        sdf.parse(date)?.let {
            formattedDate = SimpleDateFormat(format, Locale.getDefault()).format(it)
        }
    } catch (e: ParseException) {
        e.printStackTrace()
    }

    return formattedDate
}