package com.arya.moviecatalogue.ui.tvshow

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.arya.moviecatalogue.databinding.FragmentTvshowBinding
import com.arya.moviecatalogue.viewmodel.ViewModelFactory

class TvShowFragment : Fragment() {

    private lateinit var binding: FragmentTvshowBinding
    private lateinit var viewModel: TvShowViewModel
    private lateinit var tvShowAdapter: TvShowAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTvshowBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory = ViewModelFactory.getInstance(requireActivity())
        viewModel = ViewModelProvider(this, factory)[TvShowViewModel::class.java]

        tvShowAdapter = TvShowAdapter()

        binding.rvTvshow.apply {
            setHasFixedSize(true)
            adapter = tvShowAdapter
        }

        showLoading(true)
        viewModel.getTvShows().observe(viewLifecycleOwner, { tvShows ->
            showLoading(false)
            if (tvShows.isNotEmpty()) {
                tvShowAdapter.apply {
                    setTvShow(tvShows)
                    notifyDataSetChanged()
                }
                showNotify(false)
            } else {
                showNotify(true)
            }
        })
    }

    private fun showNotify(state: Boolean) {
        if (state) {
            binding.rvTvshow.visibility = View.GONE
            binding.notifyLayout.root.visibility = View.VISIBLE
        } else {
            binding.rvTvshow.visibility = View.VISIBLE
            binding.notifyLayout.root.visibility = View.GONE
        }
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.rvTvshow.visibility = View.GONE
            binding.pbTvshow.visibility = View.VISIBLE
        } else {
            binding.rvTvshow.visibility = View.VISIBLE
            binding.pbTvshow.visibility = View.GONE
        }
    }
}