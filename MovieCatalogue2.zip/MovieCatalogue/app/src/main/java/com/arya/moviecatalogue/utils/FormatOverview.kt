package com.arya.moviecatalogue.utils

fun formatOverview(overview: String): String {
    return if (overview.isEmpty()) {
        "Sorry, the synopsis is not yet available"
    } else {
        overview
    }
}