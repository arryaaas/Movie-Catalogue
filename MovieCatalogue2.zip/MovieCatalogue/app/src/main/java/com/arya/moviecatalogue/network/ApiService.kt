package com.arya.moviecatalogue.network

import com.arya.moviecatalogue.BuildConfig
import com.arya.moviecatalogue.data.source.remote.response.MovieDetailResponse
import com.arya.moviecatalogue.data.source.remote.response.MovieResponse
import com.arya.moviecatalogue.data.source.remote.response.TvShowDetailResponse
import com.arya.moviecatalogue.data.source.remote.response.TvShowResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("/3/discover/movie")
    fun getMovies(
        @Query("api_key")
        apiKey: String = BuildConfig.API_KEY
    ): Call<MovieResponse>

    @GET("/3/discover/tv")
    fun getTvShows(
        @Query("api_key")
        apiKey: String = BuildConfig.API_KEY
    ): Call<TvShowResponse>

    @GET("/3/movie/{movie_id}")
    fun getDetailMovie(
        @Path("movie_id")
        movieId: Int,
        @Query("api_key")
        apiKey: String = BuildConfig.API_KEY
    ): Call<MovieDetailResponse>

    @GET("/3/tv/{tv_id}")
    fun getDetailTvShow(
        @Path("tv_id")
        tvShowId: Int,
        @Query("api_key")
        apiKey: String = BuildConfig.API_KEY
    ): Call<TvShowDetailResponse>
}