package com.arya.moviecatalogue.data.source

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.arya.moviecatalogue.data.source.local.entity.DetailEntity
import com.arya.moviecatalogue.data.source.local.entity.MovieEntity
import com.arya.moviecatalogue.data.source.local.entity.TvShowEntity
import com.arya.moviecatalogue.data.source.remote.RemoteDataSource
import com.arya.moviecatalogue.data.source.remote.response.MovieDetailResponse
import com.arya.moviecatalogue.data.source.remote.response.MovieResult
import com.arya.moviecatalogue.data.source.remote.response.TvShowDetailResponse
import com.arya.moviecatalogue.data.source.remote.response.TvShowResult

class MovieRepository (
    private val remoteDataSource: RemoteDataSource
) : MovieDataSource {

    override fun getMovies(): LiveData<List<MovieEntity>> {
        val movieResult =  MutableLiveData<List<MovieEntity>>()
        remoteDataSource.getMovies(object : RemoteDataSource.LoadMovieCallback {
            override fun onAllMovieReceived(movieResponse: List<MovieResult>?) {
                val movieList = ArrayList<MovieEntity>()
                if (movieResponse != null) {
                    for (movie in movieResponse) {
                        with(movie) {
                            movieList.add(
                                MovieEntity(
                                    id,
                                    title,
                                    overview,
                                    releaseDate,
                                    voteAverage,
                                    posterPath,
                                    backdropPath
                                )
                            )
                        }
                    }
                }
                movieResult.postValue(movieList)
            }
        })
        return movieResult
    }

    override fun getMovieDetail(movieId: Int): LiveData<DetailEntity> {
        val movieResult = MutableLiveData<DetailEntity>()
        remoteDataSource.getMovieDetail(movieId, object : RemoteDataSource.LoadMovieDetailCallback {
            override fun onMovieDetailReceived(movieDetail: MovieDetailResponse?) {
                if (movieDetail != null) {
                    with(movieDetail) {
                        val listGenres = ArrayList<String>()

                        for (genre in genres) {
                            listGenres.add(genre.name)
                        }

                        val movie = DetailEntity(
                            id,
                            title,
                            overview,
                            releaseDate,
                            voteAverage,
                            posterPath,
                            backdropPath,
                            listGenres,
                            runtime,
                            spokenLanguages[0].name,
                            homepage
                        )
                        movieResult.postValue(movie)
                    }
                }
            }
        })
        return movieResult
    }

    override fun getTvShows(): LiveData<List<TvShowEntity>> {
        val tvShowResult =  MutableLiveData<List<TvShowEntity>>()
        remoteDataSource.getTvShows(object : RemoteDataSource.LoadTvShowCallback {
            override fun onAllTvShowReceived(tvShowResponse: List<TvShowResult>?) {
                val tvShowList = ArrayList<TvShowEntity>()
                if (tvShowResponse != null) {
                    for (tvShow in tvShowResponse) {
                        with(tvShow) {
                            tvShowList.add(
                                TvShowEntity(
                                    id,
                                    name,
                                    overview,
                                    firstAirDate,
                                    voteAverage,
                                    posterPath,
                                    backdropPath
                                )
                            )
                        }
                    }
                }
                tvShowResult.postValue(tvShowList)
            }
        })
        return tvShowResult
    }

    override fun getTvShowDetail(tvShowId: Int): LiveData<DetailEntity> {
        val tvShowResult = MutableLiveData<DetailEntity>()
        remoteDataSource.getTvShowDetail(tvShowId, object : RemoteDataSource.LoadTvShowDetailCallback {
            override fun onTvShowDetailReceived(tvShowDetail: TvShowDetailResponse?) {
                if (tvShowDetail != null) {
                    with(tvShowDetail) {
                        val listGenres = ArrayList<String>()

                        for (genre in genres) {
                            listGenres.add(genre.name)
                        }

                        val tvShow = DetailEntity(
                            id,
                            name,
                            overview,
                            firstAirDate,
                            voteAverage,
                            posterPath,
                            backdropPath,
                            listGenres,
                            runtime.average().toInt(),
                            spokenLanguages[0].englishName,
                            homepage
                        )
                        tvShowResult.postValue(tvShow)
                    }
                }
            }
        })
        return tvShowResult
    }

    companion object {
        @Volatile
        private var instance: MovieRepository? = null
        fun getInstance(remoteData: RemoteDataSource): MovieRepository =
            instance ?: synchronized(this) {
                instance ?: MovieRepository(remoteData)
            }
    }
}