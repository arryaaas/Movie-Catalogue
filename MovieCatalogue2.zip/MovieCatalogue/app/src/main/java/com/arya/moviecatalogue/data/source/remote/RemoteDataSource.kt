package com.arya.moviecatalogue.data.source.remote

import android.util.Log
import com.arya.moviecatalogue.data.source.remote.response.*
import com.arya.moviecatalogue.network.NetworkClient
import com.arya.moviecatalogue.utils.EspressoIdlingResource
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RemoteDataSource {

    fun getMovies(callback: LoadMovieCallback) {
        EspressoIdlingResource.increment()
        NetworkClient.getApiService().getMovies().enqueue(object : Callback<MovieResponse> {
            override fun onResponse(
                call: Call<MovieResponse>,
                response: Response<MovieResponse>
            ) {
                if (response.isSuccessful) {
                    response.body()?.results.let { callback.onAllMovieReceived(it) }
                }
                EspressoIdlingResource.decrement()
            }

            override fun onFailure(call: Call<MovieResponse>, t: Throwable) {
                Log.e("RemoteDataSource", "getMovies onFailure: ${t.message}")
                callback.onAllMovieReceived(emptyList())
                EspressoIdlingResource.decrement()
            }

        })
    }

    fun getTvShows(callback: LoadTvShowCallback) {
        EspressoIdlingResource.increment()
        NetworkClient.getApiService().getTvShows().enqueue(object : Callback<TvShowResponse> {
            override fun onResponse(
                call: Call<TvShowResponse>,
                response: Response<TvShowResponse>
            ) {
                if (response.isSuccessful) {
                    response.body()?.results.let { callback.onAllTvShowReceived(it) }
                }
                EspressoIdlingResource.decrement()
            }

            override fun onFailure(call: Call<TvShowResponse>, t: Throwable) {
                Log.e("RemoteDataSource", "getTvShows onFailure: ${t.message}")
                callback.onAllTvShowReceived(emptyList())
                EspressoIdlingResource.decrement()
            }

        })
    }

    fun getMovieDetail(movieId: Int, callback: LoadMovieDetailCallback) {
        EspressoIdlingResource.increment()
        NetworkClient.getApiService().getDetailMovie(movieId).enqueue(object : Callback<MovieDetailResponse> {
            override fun onResponse(
                call: Call<MovieDetailResponse>,
                response: Response<MovieDetailResponse>
            ) {
                if (response.isSuccessful) {
                    response.body()?.let { callback.onMovieDetailReceived(it) }
                }
                EspressoIdlingResource.decrement()
            }

            override fun onFailure(call: Call<MovieDetailResponse>, t: Throwable) {
                Log.e("RemoteDataSource", "getMovieDetail onFailure: ${t.message}")
                EspressoIdlingResource.decrement()
            }

        })
    }

    fun getTvShowDetail(tvShowId: Int, callback: LoadTvShowDetailCallback) {
        EspressoIdlingResource.increment()
        NetworkClient.getApiService().getDetailTvShow(tvShowId).enqueue(object : Callback<TvShowDetailResponse> {
            override fun onResponse(
                call: Call<TvShowDetailResponse>,
                response: Response<TvShowDetailResponse>
            ) {
                if (response.isSuccessful) {
                    response.body()?.let { callback.onTvShowDetailReceived(it) }
                }
                EspressoIdlingResource.decrement()
            }

            override fun onFailure(call: Call<TvShowDetailResponse>, t: Throwable) {
                Log.e("RemoteDataSource", "getTvShowDetail onFailure: ${t.message}")
                EspressoIdlingResource.decrement()
            }

        })
    }

    interface LoadMovieCallback {
        fun onAllMovieReceived(movieResponse: List<MovieResult>?)
    }

    interface LoadTvShowCallback {
        fun onAllTvShowReceived(tvShowResponse: List<TvShowResult>?)
    }

    interface LoadMovieDetailCallback {
        fun onMovieDetailReceived(movieDetail: MovieDetailResponse?)
    }

    interface  LoadTvShowDetailCallback {
        fun onTvShowDetailReceived(tvShowDetail: TvShowDetailResponse?)
    }

    companion object {
        @Volatile
        private var instance: RemoteDataSource? = null

        fun getInstance(): RemoteDataSource =
            instance ?: synchronized(this) {
                instance ?: RemoteDataSource()
            }
    }
}