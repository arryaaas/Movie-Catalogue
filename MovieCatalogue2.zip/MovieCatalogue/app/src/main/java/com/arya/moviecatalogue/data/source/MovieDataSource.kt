package com.arya.moviecatalogue.data.source

import androidx.lifecycle.LiveData
import com.arya.moviecatalogue.data.source.local.entity.DetailEntity
import com.arya.moviecatalogue.data.source.local.entity.MovieEntity
import com.arya.moviecatalogue.data.source.local.entity.TvShowEntity

interface MovieDataSource {

    fun getMovies(): LiveData<List<MovieEntity>>

    fun getMovieDetail(movieId: Int): LiveData<DetailEntity>

    fun getTvShows(): LiveData<List<TvShowEntity>>

    fun getTvShowDetail(tvShowId: Int): LiveData<DetailEntity>
}