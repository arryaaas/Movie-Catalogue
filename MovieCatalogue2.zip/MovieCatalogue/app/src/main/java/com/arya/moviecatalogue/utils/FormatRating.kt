package com.arya.moviecatalogue.utils

fun formatRating(rating: Float): String {
    return "$rating / 10"
}