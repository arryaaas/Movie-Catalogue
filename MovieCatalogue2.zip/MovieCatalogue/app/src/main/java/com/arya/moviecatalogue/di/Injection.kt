package com.arya.moviecatalogue.di

import android.content.Context
import com.arya.moviecatalogue.data.source.MovieRepository
import com.arya.moviecatalogue.data.source.remote.RemoteDataSource

object Injection {

    fun provideRepository(context: Context): MovieRepository {
        val remoteDataSource = RemoteDataSource.getInstance()
        return MovieRepository.getInstance(remoteDataSource)
    }

}