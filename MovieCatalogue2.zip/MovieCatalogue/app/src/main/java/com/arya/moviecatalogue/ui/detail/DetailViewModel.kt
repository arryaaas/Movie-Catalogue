package com.arya.moviecatalogue.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.arya.moviecatalogue.data.source.MovieRepository
import com.arya.moviecatalogue.data.source.local.entity.DetailEntity

class DetailViewModel(private val movieRepository: MovieRepository) : ViewModel() {

    private var id: Int = 0

    fun setSelectedId(id: Int) {
        this.id = id
    }

    fun getMovieDetail(): LiveData<DetailEntity> = movieRepository.getMovieDetail(id)

    fun getTvShowDetail(): LiveData<DetailEntity> = movieRepository.getTvShowDetail(id)
}