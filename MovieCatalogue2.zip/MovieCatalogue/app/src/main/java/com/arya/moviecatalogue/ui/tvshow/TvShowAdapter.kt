package com.arya.moviecatalogue.ui.tvshow

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.arya.moviecatalogue.BuildConfig.URL_POSTER
import com.arya.moviecatalogue.databinding.ItemListBinding
import com.arya.moviecatalogue.data.source.local.entity.TvShowEntity
import com.arya.moviecatalogue.ui.detail.DetailActivity
import com.arya.moviecatalogue.utils.formatDate
import com.bumptech.glide.Glide

class TvShowAdapter : RecyclerView.Adapter<TvShowAdapter.TvShowViewHolder>() {

    private var listTvShows = ArrayList<TvShowEntity>()

    fun setTvShow(tvShow: List<TvShowEntity>) {
        listTvShows.apply {
            clear()
            addAll(tvShow)
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): TvShowAdapter.TvShowViewHolder {
        return TvShowViewHolder(
            ItemListBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: TvShowAdapter.TvShowViewHolder, position: Int) {
        val tvShow = listTvShows[position]
        holder.bind(tvShow)
    }

    override fun getItemCount(): Int = listTvShows.size

    inner class TvShowViewHolder(private val binding: ItemListBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(tvShow : TvShowEntity) {
            binding.apply {
                Glide.with(itemView.context)
                    .load(URL_POSTER + tvShow.posterPath)
                    .into(binding.ivPoster)

                binding.tvTitle.text = tvShow.name
                binding.tvRelease.text = formatDate(tvShow.firstAirDate.toString(), "MMM dd, yyyy")
                binding.ratingBar.rating = tvShow.rating?.div(2F) ?: 0F
                binding.tvRating.text = tvShow.rating.toString()

                itemView.setOnClickListener {
                    Log.d("TvShow Adapter", "Item Clicked")
                    val intent = Intent(itemView.context, DetailActivity::class.java).apply {
                        putExtra(DetailActivity.EXTRA_TYPE, "TvShow")
                        putExtra(DetailActivity.EXTRA_ID, tvShow.id)
                    }
                    itemView.context.startActivity(intent)
                }
            }
        }
    }
}