package com.arya.moviecatalogue.utils

fun formatRuntime(runtime: Int): String {
    val hours = runtime / 60
    val minutes = runtime % 60
//    return if (hours == 0) "Runtime: ${minutes}min" else "Runtime: ${hours}h ${minutes}min"
    return if (hours == 0) "${minutes}min" else "${hours}h ${minutes}min"
}