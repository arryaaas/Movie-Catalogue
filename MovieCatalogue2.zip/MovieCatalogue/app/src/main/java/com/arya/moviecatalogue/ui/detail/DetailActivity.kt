package com.arya.moviecatalogue.ui.detail

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.arya.moviecatalogue.BuildConfig.URL_BACKDROP
import com.arya.moviecatalogue.BuildConfig.URL_POSTER
import com.arya.moviecatalogue.R
import com.arya.moviecatalogue.data.source.local.entity.DetailEntity
import com.arya.moviecatalogue.databinding.ActivityDetailBinding
import com.arya.moviecatalogue.utils.*
import com.arya.moviecatalogue.viewmodel.ViewModelFactory
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var viewModel: DetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.hide()

        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val factory = ViewModelFactory.getInstance(this)
        viewModel = ViewModelProvider(this, factory)[DetailViewModel::class.java]

        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
        binding.toolbar.inflateMenu(R.menu.detail_menu)

        val type = intent.getStringExtra(EXTRA_TYPE)
        val id = intent.getIntExtra(EXTRA_ID, 0)

        if (id != 0) {
            viewModel.setSelectedId(id)
            showLoading(true)
            if (type == "Movie") {
                viewModel.getMovieDetail().observe(this, { movie ->
                    showLoading(false)
                    binding.toolbar.title = "Movie Detail"
                    populateDetail(movie)
                })
            } else {
                viewModel.getTvShowDetail().observe(this, { tvShow ->
                    showLoading(false)
                    binding.toolbar.title = "Tv Show Detail"
                    populateDetail(tvShow)
                })
            }
        }
    }

    private fun populateDetail(detailEntity: DetailEntity) {
        binding.apply {
            Glide.with(this@DetailActivity)
                .load(URL_BACKDROP + detailEntity.backdropPath)
                .transform(CenterCrop())
                .into(ivBackdrop)

            Glide.with(this@DetailActivity)
                .load(URL_POSTER + detailEntity.posterPath)
                .transform(CenterCrop())
                .into(ivPoster)

            tvTitle.text = detailEntity.title
            tvRelease.text = formatDate(detailEntity.releaseDate.toString(), "MMM dd, yyyy")
            tvGenres.text = detailEntity.genres?.let { formatGenres(it) }
            tvRuntime.text = detailEntity.runtime?.let { formatRuntime(it) }
            tvLanguage.text = detailEntity.language
            tvRating.text = detailEntity.rating?.let { formatRating(it) }
            tvOverview.text = detailEntity.overview?.let { formatOverview(it) }

            toolbar.setOnMenuItemClickListener{
                when (it.itemId) {
                    R.id.action_share -> {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, detailEntity.homepage)
                            type = "text/plain"
                        }
                        val shareIntent = Intent.createChooser(sendIntent, null)
                        startActivity(shareIntent)
                    }
                }
                false
            }
        }
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.collapsingToolbar.visibility = View.GONE
            binding.content.visibility = View.GONE
            binding.pbMovie.visibility = View.VISIBLE
        } else {
            binding.collapsingToolbar.visibility = View.VISIBLE
            binding.content.visibility = View.VISIBLE
            binding.pbMovie.visibility = View.GONE
        }
    }

    companion object {
        const val EXTRA_TYPE = "type"
        const val EXTRA_ID = "id"
    }
}