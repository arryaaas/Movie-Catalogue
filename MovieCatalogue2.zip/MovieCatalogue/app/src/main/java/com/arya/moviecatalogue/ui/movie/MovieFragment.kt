package com.arya.moviecatalogue.ui.movie

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.arya.moviecatalogue.databinding.FragmentMovieBinding
import com.arya.moviecatalogue.viewmodel.ViewModelFactory

class MovieFragment : Fragment() {

    private lateinit var binding: FragmentMovieBinding
    private lateinit var viewModel: MovieViewModel
    private lateinit var movieAdapter: MovieAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMovieBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory = ViewModelFactory.getInstance(requireActivity())
        viewModel = ViewModelProvider(this, factory)[MovieViewModel::class.java]

        movieAdapter = MovieAdapter()

        binding.rvMovie.apply {
            setHasFixedSize(true)
            adapter = movieAdapter
        }

        showLoading(true)
        viewModel.getMovies().observe(viewLifecycleOwner, { movies ->
            showLoading(false)
            if (movies.isNotEmpty()) {
                movieAdapter.apply {
                    setMovie(movies)
                    notifyDataSetChanged()
                }
                showNotify(false)
            } else {
                showNotify(true)
            }
        })
    }

    private fun showNotify(state: Boolean) {
        if (state) {
            binding.rvMovie.visibility = View.GONE
            binding.notifyLayout.root.visibility = View.VISIBLE
        } else {
            binding.rvMovie.visibility = View.VISIBLE
            binding.notifyLayout.root.visibility = View.GONE
        }
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.rvMovie.visibility = View.GONE
            binding.pbMovie.visibility = View.VISIBLE
        } else {
            binding.rvMovie.visibility = View.VISIBLE
            binding.pbMovie.visibility = View.GONE
        }
    }
}