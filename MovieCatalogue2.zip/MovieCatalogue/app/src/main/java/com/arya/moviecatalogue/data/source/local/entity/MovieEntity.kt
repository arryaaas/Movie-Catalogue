package com.arya.moviecatalogue.data.source.local.entity

import android.os.Parcel
import android.os.Parcelable

data class MovieEntity(
    var id: Int? = 0,
    var title: String? = null,
    var overview: String? = null,
    var releaseDate: String? = null,
    var rating: Float? = 0F,
    var posterPath: String? = null,
    var backdropPath: String? = null,
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readValue(Int::class.java.classLoader) as? Int,
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readValue(Float::class.java.classLoader) as? Float,
        parcel.readString(),
        parcel.readString()
    )

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(p0: Parcel, p1: Int) {
        id?.let { p0.writeInt(it) }
        p0.writeString(title)
        p0.writeString(overview)
        p0.writeString(releaseDate)
        rating?.let { p0.writeFloat(it) }
        p0.writeString(posterPath)
        p0.writeString(backdropPath)
    }

    companion object CREATOR : Parcelable.Creator<MovieEntity> {
        override fun createFromParcel(parcel: Parcel): MovieEntity {
            return MovieEntity(parcel)
        }

        override fun newArray(size: Int): Array<MovieEntity?> {
            return arrayOfNulls(size)
        }
    }
}