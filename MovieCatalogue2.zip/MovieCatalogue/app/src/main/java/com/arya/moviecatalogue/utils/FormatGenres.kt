package com.arya.moviecatalogue.utils

fun formatGenres(genres: List<String>): String {
    return genres.toString().replace("[", "").replace("]", "")
}