package com.arya.moviecatalogue.data.source.remote.response

import com.google.gson.annotations.SerializedName

data class Language (

    @field:SerializedName("english_name")
    val englishName: String,

    @field:SerializedName("iso_639_1")
    val iso: String,

    @field:SerializedName("name")
    val name: String,

)